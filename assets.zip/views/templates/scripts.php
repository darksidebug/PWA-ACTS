    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <link rel="stylesheet" href="../../assets/js/bootstrap.bundle.min.js">
    <link rel="stylesheet" href="../../assets/js/jquery-3.5.1.js">
    <link rel="stylesheet" href="../../assets/js/moment.min.js">
    <link rel="stylesheet" href="../../assets/js/bootstrap.min.js">
    <link rel="stylesheet" href="../../assets/js/jquery.easing.min.js">
    <link rel="stylesheet" href="../../assets/js/sweetalert.min.js">
    <script rel='prefetch prerender' src="../../assets/js/feather.min.js"></script>
    <script>
        feather.replace()
    </script>