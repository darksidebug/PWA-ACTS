<?php include '../templates/header.php' ?>
<div class="container">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            no Connection
        </div>
    </div>
</div>
<?php include('../templates/footer.php'); ?>